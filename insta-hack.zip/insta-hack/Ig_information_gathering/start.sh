clear
echo -e "$Yellow                            processing please wait ---> 13%"
sleep 2.0
clear
echo -e "$Yellow                            processing please wait ----------------> 100%"
sleep 2.0
clear
echo " "
cd Core_files
python3 Ig_information_gathering.py
