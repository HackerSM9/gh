# Insta-Hack by HackerSM9
![Discription](https://socialify-pt57hdgtz-whe.vercel.app/HackerSM9/insta-hack/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pattern=Circuit%20Board&pulls=1&stargazers=1&theme=Dark)
<p align="center">
  <img src="https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful!&style=for-the-badge&color=410694"><br>
  <img src="https://img.shields.io/badge/Version-9.0.0-green?style=for-the-badge">
  <img src="https://img.shields.io/github/license/HackerSM9/insta-hack?style=for-the-badge&color=teal">
  <img src="https://img.shields.io/github/stars/HackerSM9/insta-hack?style=for-the-badge">
  <img src="https://img.shields.io/github/forks/HackerSM9/insta-hack?style=for-the-badge">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Author-HackerSM9-purple?style=flat-square">
  <img src="https://img.shields.io/badge/Open%20Source-Yes-darkgreen?style=flat-square">
  <img src="https://img.shields.io/badge/Maintained%3F-Yes-lightblue?style=flat-square">
  <img src="https://img.shields.io/badge/Written%20In-Python-darkcyan?style=flat-square">
  <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FHackerSM9%2Finsta-hack&title=Visitors&edge_flat=false"/></a>
</p>

# Disclaimer:
> **_Note_**: You shall not misuse the information to gain unauthorised access. I will not be Responsible for Anything, Use at Your Own Risk..⚠️ 

> **_Note_**: This not for **illegal usage..⚠️**

## About tool
All in one Instagram hacking tool available (Insta information gathering, Insta brute force, Insta account auto repoter)

## Features:

- Insta information gathering
- Insta brute force attack
- Insta auto repoter
- Update script
- Remove script

## Requirements
- Data connection
- Internet 200MB
- storage 400MB
- No Root

## Available On
- Termux
- Kali Linux

## Test On:
- Termux
- ANDROID 6+

## INSTALLATION [Termux]

```shell
 apt update
 apt upgrade
 pkg install python
 pkg install python3
 pkg install git
 git clone https://github.com/HackerSM9/insta-hack
 ls
 cd insta-hack
 pip3 install -r requirements.txt
 chmod +x *
 bash setup
```

## INSTALLATION [Kali Linux]

```shell
 sudo apt install python
 sudo apt install python3
 sudo apt install git
 git clone https://github.com/HackerSM9/insta-hack
 ls
 cd insta-hack
 pip3 install -r requirements.txt
 chmod +x *
 sudo python3 insta-hack.py
```

## Screenshot:
<br>
<p align="center">
<img width="95%" src="https://camo.githubusercontent.com/7b28dfee7fe01ba7a60eabd459315dd46ac27ba77e036f257b28b5a9eed3746d/68747470733a2f2f626c6f676765722e676f6f676c6575736572636f6e74656e742e636f6d2f696d672f622f523239765a32786c2f415676587345673055565a46793657784f775f357a46575141784a65676264314e364636634b4f696b3752364b414d4d4d70444c427667386d5950537034467034587a4f3753556c51716a696f4a5f6d4361514c7345656564574445746179544f724f787668387966586a696a3147376b6f476b3245736e6d53665136762d706f65544e73475261454961726864716b504b323941717273324f5263543970656539654262734f724b6671685070506c61784d6d544374786976504c5278774f2f73323334302f53637265656e73686f745f323032322d31322d32322d32312d30302d31342d3839355f636f6d2e7465726d75782e6a70673f73616e6974697a653d74727565?sanitize=true">
<img width="95%" src="https://camo.githubusercontent.com/32af89057587363c5b9467a6815bbd3adbeb4d0d5a434bdc6acadaf684f04b55/68747470733a2f2f626c6f676765722e676f6f676c6575736572636f6e74656e742e636f6d2f696d672f622f523239765a32786c2f41567658734568622d68686d657a50666f5163686a666552636c556448384562477769335f53316e487858496e57456a4e524b496266305f34416a4b4d7161796d78437a334f7851797a46326b554b3464654a57385a665a4f426a5973626746757764554f4e6446646d354e6d4b586346556d423635585361756a3166526b705a793477616a584376654c354e565f35556f2d38446161525f59516b4f5a326b363733617841637761464870537464444c4671526c6b4d5f39595f34676a672d2f73323334302f53637265656e73686f745f323032332d30312d31302d31332d32382d34302d3036395f636f6d2e7465726d75782e6a7067"\>
</p>
