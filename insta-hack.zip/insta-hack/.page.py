import os,sys

usr = input("\n\033[1;32mHackerSM9 / UserName $ ")
os.system("python3 id_insta.py -u {0}".format(usr))
